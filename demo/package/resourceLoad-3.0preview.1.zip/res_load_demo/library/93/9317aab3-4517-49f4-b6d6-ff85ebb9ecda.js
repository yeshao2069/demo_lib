System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Sprite, resources, Prefab, instantiate, director, SpriteFrame, _dec, _dec2, _class, _class2, _descriptor, _class3, _temp, _crd, ccclass, property, ResLoadDemo;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; subClass.__proto__ = superClass; }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _class3: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Sprite = _cc.Sprite;
      resources = _cc.resources;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      director = _cc.director;
      SpriteFrame = _cc.SpriteFrame;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "9317aqzRRdJ9LbW/4Xrueza", "ResLoadDemo", _context.meta);

      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("ResLoadDemo", ResLoadDemo = (_dec = ccclass('ResLoadDemo'), _dec2 = property(Sprite), _dec(_class = (_class2 = (_temp = _class3 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(ResLoadDemo, _Component);

        function ResLoadDemo() {
          var _this;

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _Component.call.apply(_Component, [this].concat(args)) || this;

          _initializerDefineProperty(_assertThisInitialized(_this), "sprite", _descriptor, _assertThisInitialized(_this));

          return _this;
        }

        var _proto = ResLoadDemo.prototype;

        _proto.start = function start() {
          var _this2 = this;

          // 演示加载prefab，加载成功的话，屏幕中会出现一个cube
          resources.load(ResLoadDemo.PREFAB_URL, Prefab, function (err, prefab) {
            if (err) {
              console.log('Load ' + ResLoadDemo.PREFAB_URL + ' failed.');
              return;
            }

            if (prefab) {
              var _director$getScene;

              (_director$getScene = director.getScene()) === null || _director$getScene === void 0 ? void 0 : _director$getScene.addChild(instantiate(prefab));
            }
          }); // 演示加载spriteframe，加载成功，屏幕中会一个图片

          resources.load(ResLoadDemo.SPRITE_FRAME_URL, SpriteFrame, function (err, spriteFrame) {
            if (err) {
              console.log('Load ' + ResLoadDemo.SPRITE_FRAME_URL + ' failed.');
              return;
            }

            if (spriteFrame && _this2.sprite) {
              _this2.sprite.spriteFrame = spriteFrame;
            }
          });
        };

        return ResLoadDemo;
      }(Component), _defineProperty(_class3, "PREFAB_URL", "Cube"), _defineProperty(_class3, "SPRITE_FRAME_URL", "light/spriteFrame"), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "sprite", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvY29jb3MvT25lRHJpdmUvJUU2JUExJThDJUU5JTlEJUEyL3Jlc19sb2FkX2RlbW8vYXNzZXRzL3NjcmlwdHMvUmVzTG9hZERlbW8udHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsIkNvbXBvbmVudCIsIlNwcml0ZSIsInJlc291cmNlcyIsIlByZWZhYiIsImluc3RhbnRpYXRlIiwiZGlyZWN0b3IiLCJTcHJpdGVGcmFtZSIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIlJlc0xvYWREZW1vIiwic3RhcnQiLCJsb2FkIiwiUFJFRkFCX1VSTCIsImVyciIsInByZWZhYiIsImNvbnNvbGUiLCJsb2ciLCJnZXRTY2VuZSIsImFkZENoaWxkIiwiU1BSSVRFX0ZSQU1FX1VSTCIsInNwcml0ZUZyYW1lIiwic3ByaXRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFPU0EsTUFBQUEsVSxPQUFBQSxVO0FBQVlDLE1BQUFBLFMsT0FBQUEsUztBQUFpQkMsTUFBQUEsTSxPQUFBQSxNO0FBQVFDLE1BQUFBLFMsT0FBQUEsUztBQUFXQyxNQUFBQSxNLE9BQUFBLE07QUFBUUMsTUFBQUEsVyxPQUFBQSxXO0FBQzdEQyxNQUFBQSxRLE9BQUFBLFE7QUFBVUMsTUFBQUEsVyxPQUFBQSxXOzs7Ozs7O0FBQ05DLE1BQUFBLE8sR0FBc0JSLFUsQ0FBdEJRLE87QUFBU0MsTUFBQUEsUSxHQUFhVCxVLENBQWJTLFE7OzZCQUdKQyxXLFdBRFpGLE9BQU8sQ0FBQyxhQUFELEMsVUFLSEMsUUFBUSxDQUFDUCxNQUFELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7ZUFHVFMsSyxHQUFBLGlCQUFRO0FBQUE7O0FBQ0o7QUFDQVIsVUFBQUEsU0FBUyxDQUFDUyxJQUFWLENBQWVGLFdBQVcsQ0FBQ0csVUFBM0IsRUFBdUNULE1BQXZDLEVBQStDLFVBQUNVLEdBQUQsRUFBTUMsTUFBTixFQUFpQjtBQUM1RCxnQkFBSUQsR0FBSixFQUFTO0FBQ0xFLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVVQLFdBQVcsQ0FBQ0csVUFBdEIsR0FBbUMsVUFBL0M7QUFDQTtBQUNIOztBQUVELGdCQUFJRSxNQUFKLEVBQVk7QUFBQTs7QUFDUixvQ0FBQVQsUUFBUSxDQUFDWSxRQUFULDRFQUFxQkMsUUFBckIsQ0FBOEJkLFdBQVcsQ0FBQ1UsTUFBRCxDQUF6QztBQUNIO0FBQ0osV0FURCxFQUZJLENBYUo7O0FBQ0FaLFVBQUFBLFNBQVMsQ0FBQ1MsSUFBVixDQUFlRixXQUFXLENBQUNVLGdCQUEzQixFQUE2Q2IsV0FBN0MsRUFBMEQsVUFBQ08sR0FBRCxFQUFNTyxXQUFOLEVBQXNCO0FBQ3hFLGdCQUFJUCxHQUFKLEVBQVM7QUFDTEUsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBVVAsV0FBVyxDQUFDVSxnQkFBdEIsR0FBeUMsVUFBckQ7QUFDQTtBQUNIOztBQUVELGdCQUFJQyxXQUFXLElBQUksTUFBSSxDQUFDQyxNQUF4QixFQUFnQztBQUM1QixjQUFBLE1BQUksQ0FBQ0EsTUFBTCxDQUFZRCxXQUFaLEdBQTBCQSxXQUExQjtBQUNIO0FBQ0osV0FUTDtBQVdILFM7OztRQWhDNEJwQixTLDBDQUNBLE0sZ0RBQ00sbUI7Ozs7O2lCQUdYLEkiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLyoqXHJcbiAqIGNyZWF0ZWQgYnk6IGR0XHJcbiAqIGNyZWF0ZWQgYXQ6IDIwMjAvMTIvMTVcclxuICogcHVycG9zZTpcclxuICogZm9yIGRlbW9zdHJhdGluZyB0aGUgcHJvYmxlbSB3aGVuIGxvYWRpbmcgU3ByaXRlRnJhbWUgZnJvbSByZXNvdXJjZXMgZm9sZGVyLlxyXG4gKi9cclxuaW1wb3J0IHsgX2RlY29yYXRvciwgQ29tcG9uZW50LCBOb2RlLCBTcHJpdGUsIHJlc291cmNlcywgUHJlZmFiLCBpbnN0YW50aWF0ZSwgXHJcbiAgICBkaXJlY3RvciwgU3ByaXRlRnJhbWUgfSBmcm9tICdjYyc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzcygnUmVzTG9hZERlbW8nKVxyXG5leHBvcnQgY2xhc3MgUmVzTG9hZERlbW8gZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gICAgc3RhdGljIHJlYWRvbmx5IFBSRUZBQl9VUkwgPSBcIkN1YmVcIjtcclxuICAgIHN0YXRpYyByZWFkb25seSBTUFJJVEVfRlJBTUVfVVJMID0gXCJsaWdodC9zcHJpdGVGcmFtZVwiO1xyXG5cclxuICAgIEBwcm9wZXJ0eShTcHJpdGUpXHJcbiAgICBzcHJpdGU6IFNwcml0ZSB8IG51bGwgPSBudWxsO1xyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIC8vIOa8lOekuuWKoOi9vXByZWZhYu+8jOWKoOi9veaIkOWKn+eahOivne+8jOWxj+W5leS4reS8muWHuueOsOS4gOS4qmN1YmVcclxuICAgICAgICByZXNvdXJjZXMubG9hZChSZXNMb2FkRGVtby5QUkVGQUJfVVJMLCBQcmVmYWIsIChlcnIsIHByZWZhYikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnTG9hZCAnICsgUmVzTG9hZERlbW8uUFJFRkFCX1VSTCArICcgZmFpbGVkLicpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAocHJlZmFiKSB7XHJcbiAgICAgICAgICAgICAgICBkaXJlY3Rvci5nZXRTY2VuZSgpPy5hZGRDaGlsZChpbnN0YW50aWF0ZShwcmVmYWIhKSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8g5ryU56S65Yqg6L29c3ByaXRlZnJhbWXvvIzliqDovb3miJDlip/vvIzlsY/luZXkuK3kvJrkuIDkuKrlm77niYdcclxuICAgICAgICByZXNvdXJjZXMubG9hZChSZXNMb2FkRGVtby5TUFJJVEVfRlJBTUVfVVJMLCBTcHJpdGVGcmFtZSwgKGVyciwgc3ByaXRlRnJhbWUpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnTG9hZCAnICsgUmVzTG9hZERlbW8uU1BSSVRFX0ZSQU1FX1VSTCArICcgZmFpbGVkLicpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgIFxyXG4gICAgICAgICAgICAgICAgaWYgKHNwcml0ZUZyYW1lICYmIHRoaXMuc3ByaXRlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zcHJpdGUuc3ByaXRlRnJhbWUgPSBzcHJpdGVGcmFtZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==