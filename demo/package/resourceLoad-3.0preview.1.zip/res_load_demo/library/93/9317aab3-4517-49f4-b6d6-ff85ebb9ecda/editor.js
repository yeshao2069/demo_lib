System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Sprite, resources, Prefab, instantiate, director, SpriteFrame, _dec, _dec2, _class, _class2, _descriptor, _class3, _temp, _crd, ccclass, property, ResLoadDemo;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _class3: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Sprite = _cc.Sprite;
      resources = _cc.resources;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      director = _cc.director;
      SpriteFrame = _cc.SpriteFrame;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "9317aqzRRdJ9LbW/4Xrueza", "ResLoadDemo", _context.meta);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ResLoadDemo", ResLoadDemo = (_dec = ccclass('ResLoadDemo'), _dec2 = property(Sprite), _dec(_class = (_class2 = (_temp = _class3 = class ResLoadDemo extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "sprite", _descriptor, this);
        }

        start() {
          // 演示加载prefab，加载成功的话，屏幕中会出现一个cube
          resources.load(ResLoadDemo.PREFAB_URL, Prefab, (err, prefab) => {
            if (err) {
              console.log('Load ' + ResLoadDemo.PREFAB_URL + ' failed.');
              return;
            }

            if (prefab) {
              var _director$getScene;

              (_director$getScene = director.getScene()) === null || _director$getScene === void 0 ? void 0 : _director$getScene.addChild(instantiate(prefab));
            }
          }); // 演示加载spriteframe，加载成功，屏幕中会一个图片

          resources.load(ResLoadDemo.SPRITE_FRAME_URL, SpriteFrame, (err, spriteFrame) => {
            if (err) {
              console.log('Load ' + ResLoadDemo.SPRITE_FRAME_URL + ' failed.');
              return;
            }

            if (spriteFrame && this.sprite) {
              this.sprite.spriteFrame = spriteFrame;
            }
          });
        }

      }, _defineProperty(_class3, "PREFAB_URL", "Cube"), _defineProperty(_class3, "SPRITE_FRAME_URL", "light/spriteFrame"), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "sprite", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvY29jb3MvT25lRHJpdmUvJUU2JUExJThDJUU5JTlEJUEyL3Jlc19sb2FkX2RlbW8vYXNzZXRzL3NjcmlwdHMvUmVzTG9hZERlbW8udHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsIkNvbXBvbmVudCIsIlNwcml0ZSIsInJlc291cmNlcyIsIlByZWZhYiIsImluc3RhbnRpYXRlIiwiZGlyZWN0b3IiLCJTcHJpdGVGcmFtZSIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIlJlc0xvYWREZW1vIiwic3RhcnQiLCJsb2FkIiwiUFJFRkFCX1VSTCIsImVyciIsInByZWZhYiIsImNvbnNvbGUiLCJsb2ciLCJnZXRTY2VuZSIsImFkZENoaWxkIiwiU1BSSVRFX0ZSQU1FX1VSTCIsInNwcml0ZUZyYW1lIiwic3ByaXRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU9TQSxNQUFBQSxVLE9BQUFBLFU7QUFBWUMsTUFBQUEsUyxPQUFBQSxTO0FBQWlCQyxNQUFBQSxNLE9BQUFBLE07QUFBUUMsTUFBQUEsUyxPQUFBQSxTO0FBQVdDLE1BQUFBLE0sT0FBQUEsTTtBQUFRQyxNQUFBQSxXLE9BQUFBLFc7QUFDN0RDLE1BQUFBLFEsT0FBQUEsUTtBQUFVQyxNQUFBQSxXLE9BQUFBLFc7Ozs7Ozs7T0FDUjtBQUFFQyxRQUFBQSxPQUFGO0FBQVdDLFFBQUFBO0FBQVgsTyxHQUF3QlQsVTs7NkJBR2pCVSxXLFdBRFpGLE9BQU8sQ0FBQyxhQUFELEMsVUFLSEMsUUFBUSxDQUFDUCxNQUFELEMsOENBTGIsTUFDYVEsV0FEYixTQUNpQ1QsU0FEakMsQ0FDMkM7QUFBQTtBQUFBOztBQUFBO0FBQUE7O0FBT3ZDVSxRQUFBQSxLQUFLLEdBQUc7QUFDSjtBQUNBUixVQUFBQSxTQUFTLENBQUNTLElBQVYsQ0FBZUYsV0FBVyxDQUFDRyxVQUEzQixFQUF1Q1QsTUFBdkMsRUFBK0MsQ0FBQ1UsR0FBRCxFQUFNQyxNQUFOLEtBQWlCO0FBQzVELGdCQUFJRCxHQUFKLEVBQVM7QUFDTEUsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBVVAsV0FBVyxDQUFDRyxVQUF0QixHQUFtQyxVQUEvQztBQUNBO0FBQ0g7O0FBRUQsZ0JBQUlFLE1BQUosRUFBWTtBQUFBOztBQUNSLG9DQUFBVCxRQUFRLENBQUNZLFFBQVQsNEVBQXFCQyxRQUFyQixDQUE4QmQsV0FBVyxDQUFDVSxNQUFELENBQXpDO0FBQ0g7QUFDSixXQVRELEVBRkksQ0FhSjs7QUFDQVosVUFBQUEsU0FBUyxDQUFDUyxJQUFWLENBQWVGLFdBQVcsQ0FBQ1UsZ0JBQTNCLEVBQTZDYixXQUE3QyxFQUEwRCxDQUFDTyxHQUFELEVBQU1PLFdBQU4sS0FBc0I7QUFDeEUsZ0JBQUlQLEdBQUosRUFBUztBQUNMRSxjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFVUCxXQUFXLENBQUNVLGdCQUF0QixHQUF5QyxVQUFyRDtBQUNBO0FBQ0g7O0FBRUQsZ0JBQUlDLFdBQVcsSUFBSSxLQUFLQyxNQUF4QixFQUFnQztBQUM1QixtQkFBS0EsTUFBTCxDQUFZRCxXQUFaLEdBQTBCQSxXQUExQjtBQUNIO0FBQ0osV0FUTDtBQVdIOztBQWhDc0MsTyx5Q0FDVixNLGdEQUNNLG1COzs7OztpQkFHWCxJIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi8qKlxyXG4gKiBjcmVhdGVkIGJ5OiBkdFxyXG4gKiBjcmVhdGVkIGF0OiAyMDIwLzEyLzE1XHJcbiAqIHB1cnBvc2U6XHJcbiAqIGZvciBkZW1vc3RyYXRpbmcgdGhlIHByb2JsZW0gd2hlbiBsb2FkaW5nIFNwcml0ZUZyYW1lIGZyb20gcmVzb3VyY2VzIGZvbGRlci5cclxuICovXHJcbmltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgU3ByaXRlLCByZXNvdXJjZXMsIFByZWZhYiwgaW5zdGFudGlhdGUsIFxyXG4gICAgZGlyZWN0b3IsIFNwcml0ZUZyYW1lIH0gZnJvbSAnY2MnO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3MoJ1Jlc0xvYWREZW1vJylcclxuZXhwb3J0IGNsYXNzIFJlc0xvYWREZW1vIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuICAgIHN0YXRpYyByZWFkb25seSBQUkVGQUJfVVJMID0gXCJDdWJlXCI7XHJcbiAgICBzdGF0aWMgcmVhZG9ubHkgU1BSSVRFX0ZSQU1FX1VSTCA9IFwibGlnaHQvc3ByaXRlRnJhbWVcIjtcclxuXHJcbiAgICBAcHJvcGVydHkoU3ByaXRlKVxyXG4gICAgc3ByaXRlOiBTcHJpdGUgfCBudWxsID0gbnVsbDtcclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICAvLyDmvJTnpLrliqDovb1wcmVmYWLvvIzliqDovb3miJDlip/nmoTor53vvIzlsY/luZXkuK3kvJrlh7rnjrDkuIDkuKpjdWJlXHJcbiAgICAgICAgcmVzb3VyY2VzLmxvYWQoUmVzTG9hZERlbW8uUFJFRkFCX1VSTCwgUHJlZmFiLCAoZXJyLCBwcmVmYWIpID0+IHtcclxuICAgICAgICAgICAgaWYgKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0xvYWQgJyArIFJlc0xvYWREZW1vLlBSRUZBQl9VUkwgKyAnIGZhaWxlZC4nKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHByZWZhYikge1xyXG4gICAgICAgICAgICAgICAgZGlyZWN0b3IuZ2V0U2NlbmUoKT8uYWRkQ2hpbGQoaW5zdGFudGlhdGUocHJlZmFiISkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIOa8lOekuuWKoOi9vXNwcml0ZWZyYW1l77yM5Yqg6L295oiQ5Yqf77yM5bGP5bmV5Lit5Lya5LiA5Liq5Zu+54mHXHJcbiAgICAgICAgcmVzb3VyY2VzLmxvYWQoUmVzTG9hZERlbW8uU1BSSVRFX0ZSQU1FX1VSTCwgU3ByaXRlRnJhbWUsIChlcnIsIHNwcml0ZUZyYW1lKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0xvYWQgJyArIFJlc0xvYWREZW1vLlNQUklURV9GUkFNRV9VUkwgKyAnIGZhaWxlZC4nKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICBcclxuICAgICAgICAgICAgICAgIGlmIChzcHJpdGVGcmFtZSAmJiB0aGlzLnNwcml0ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3ByaXRlLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=