/// <reference path="L:\work\CocosDashboard\resources\.editors\Creator\3.0.0-Preview.1\resources\resources\3d\jsb-adapter\@types\jsb.d.ts"/>
